<?php
require_once 'config.php';
CONFIG::connect();

function startswith($haystack, $needle){
  return strpos($haystack, $needle) === 0;
}

function add_group($count, $active){
  for($i=0; $i<$count; $i++){
    CONFIG::query('
    INSERT INTO groups(active)
    VALUES(?);
  ', array($active)) or die(mysql_error());
  }
}

function set_group_activeness($group_id, $active){
  CONFIG::query('
    UPDATE groups
    SET active = ?
    WHERE id = ?;
  ', array($active, $group_id)) or die(mysql_error());
}

function remove_group($id){
  #TODO wont delete from peer_evaluation or peer_evaluation_reponses
  //get a list of the users in the group
  $usernames_to_delete = CONFIG::query('
    SELECT username
    FROM students
    WHERE group_id = ?;
  ', array($id));
  //for each user in the group
  while($row = mysql_fetch_assoc($usernames_to_delete)){
    //get a list of peer evals they were in, either reviewing someone or being reviewed
    $peer_evals_to_delete = CONFIG::query('
      SELECT id
      FROM peer_evaluation
      WHERE
        (reviewer = ?)
        OR
        (reviewee = ?);
    ', array($row['username'], $row['username']));
    //for each user's peer eval
    while($pe_row = mysql_fetch_assoc($peer_evals_to_delete)){
      //delete their responses
      CONFIG::query('
        DELETE
        FROM peer_evaluation_responses
        WHERE evaluation_id = ?;
      ', array($pe_row['id']));
      //delete their actual evals
      CONFIG::query('
        DELETE
        FROM peer_evaluation
        WHERE id = ?;
      ', array($pe_row['id']));
    }

    //remove user from students table
    CONFIG::query('
      DELETE
      FROM students
      WHERE username = ?;
    ', array($row['username']));
    //remove each user from users table
    CONFIG::query('
      DELETE
      FROM users
      WHERE username = ?;
    ', array($row['username']));
  }
  //remove the group
  CONFIG::query('
    DELETE
    FROM groups
    WHERE id = ?;
  ', array($id)) or die(mysql_error());
}

$action = $_REQUEST['action'];
$previous_page = $_REQUEST['previous_page'];

if($action === 'Add Active Groups'){
  add_group($_REQUEST['group_count'], 1);
  CONFIG::redirect("$previous_page?num_groups_added={$_REQUEST['group_count']}&active=1");
}
if($action === 'Add Inactive Groups'){
  add_group($_REQUEST['group_count'], 0);
  CONFIG::redirect("$previous_page?num_groups_added={$_REQUEST['group_count']}&active=0");
}
if($action === 'Make Active'){
  foreach($_REQUEST as $key => $value){
    if(startswith($key, 'selection_')){
      $new_key = substr($key, strlen('selection_'));
      set_group_activeness($new_key, 1);
    }
  }
  CONFIG::redirect("$previous_page?made_active=1");
}
if($action === 'Make Inactive'){
  foreach($_REQUEST as $key => $value){
    if(startswith($key, 'selection_')){
      $new_key = substr($key, strlen('selection_'));
      set_group_activeness($new_key, 0);
    }
  }
  CONFIG::redirect("$previous_page?made_active=0");
}

if($action === 'Remove'){
  foreach($_REQUEST as $key => $value){
    if(startswith($key, 'selection_')){
      $new_key = substr($key, strlen('selection_'));
      remove_group($new_key);
    }
  }
  CONFIG::redirect("$previous_page?groups_removed=1");
}
