<?php
require_once 'config.php';
require_once 'menu_admin.php';
require_once 'footer.php';
CONFIG::continue_session();
CONFIG::connect();

$t = new vlibTemplate('create_admin.tmpl');
$t->setvar('previous_page', $_SERVER['PHP_SELF']);
$t->setdbloop('title', CONFIG::query('
  SELECT id, text
  FROM titles;
'));

$layout = new vlibTemplate('layout.tmpl');
$layout->setvar('main', $t->grab());
$layout->setvar('title', 'Create an Administrator');
$layout->setvar('navigation', menu_admin());
$layout->setvar('footer', footer());

$layout->pparse();
