<?php
require_once 'config.php';
require_once 'menu_admin.php';
require_once 'footer.php';
CONFIG::continue_session();
CONFIG::connect();

$t = new vlibTemplate('view_reports.tmpl');
$peer_eval_groups = array();
for($i = 1; $i <= 8; $i++){
  array_push($peer_eval_groups, array('group_id'=> "$i"));
}
$t->setloop('peer_evaluation_groups', $peer_eval_groups);
$t->setloop('group_eval_groups', $peer_eval_groups);

$layout = new vlibTemplate('layout.tmpl');
$layout->setvar('main', $t->grab());
$layout->setvar('title', 'View Reports');
$layout->setvar('navigation', menu_admin());
$layout->setvar('footer', footer());

$layout->pparse();
