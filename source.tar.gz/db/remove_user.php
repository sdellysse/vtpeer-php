<?php
require_once 'config.php';

function remove_group($group_id){
  $sql = CONFIG::query('
    SELECT username
    FROM students
    WHERE group_id = ?;
  ', array($group_id));
  while($row = mysql_fetch_assoc($sql)){
    remove_user($row['username']);
    CONFIG::query('
      DELETE
      FROM groups
      WHERE id = ?;
    ', array($group_id)) or die(mysql_error());
  }
}

function remove_user($username){
  remove_peer_evaluations_containing_user($username);
  CONFIG::query('
    DELETE
    FROM students
    WHERE username = ?;
  ', array($username)) or die(mysql_error());
  CONFIG::query('
    DELETE
    FROM users
    WHERE username = ?;
  ', array($username)) or die(mysql_error());
}

function remove_peer_evaluations_containing_user($username){
  $sql = CONFIG::query('
    SELECT id
    FROM peer_evaluation
    WHERE (reviewer = ?) OR (reviewee = ?);
  ', array($username, $username));
  while($row = mysql_fetch_assoc($sql)){
    remove_peer_evaluation_response_by_evaluation_id($row['id']);
    CONFIG::query('
      DELETE
      FROM peer_evaluation
      WHERE id = ?;
    ', array($row['id'])) or die(mysql_error());
  }
}

function remove_peer_evaluation_response_by_evaluation_id($evaluation_id){
  CONFIG::query('
    DELETE
    FROM peer_evaluation_response
    WHERE evaluation_id = ?;
  ', array($evaluation_id)) or die(mysql_error());
}

