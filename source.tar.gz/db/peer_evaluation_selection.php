<?php
require_once 'config.php';
require_once 'menu_student.php';
require_once 'footer.php';
CONFIG::continue_session();
CONFIG::connect();

$t = new vlibTemplate('peer_evaluation_selection.tmpl');
$t->setdbloop('members',CONFIG::query('
  SELECT reviewee AS username, first_name, last_name, role_name AS role
  FROM reviewer_reviewee_matrix INNER JOIN student_information
  ON reviewer_reviewee_matrix.reviewee = student_information.username
  WHERE reviewer = ?;
', array(CONFIG::session_get('username'))));
$t->setvar('previous_page', $_SERVER['PHP_SELF']);

$layout = new vlibTemplate('layout.tmpl');
$layout->setvar('main', $t->grab());
$layout->setvar('navigation', menu_student());
$layout->setvar('footer', footer());
$layout->setvar('title', 'Select a Peer Evaluation');

$layout->pparse();

